
#ifndef  __I2_C__
#define __I2_C__

extern void twi_init (void);
extern void temperature_sensor_read_status_fnc(void);
extern int twiWriteData(uint8_t address, uint8_t * p_data, uint8_t length);
extern int twiReadData(uint8_t address, uint8_t * p_data, uint8_t length);
extern void twi_enable_fnc(void);
extern void twi_disable_fnc(void);
extern void twi_deinit (void);



#endif