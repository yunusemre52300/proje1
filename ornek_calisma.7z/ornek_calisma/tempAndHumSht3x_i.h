
#ifndef  __TEMP_AND_HUM_STH3X_I__
#define __TEMP_AND_HUM_STH3X_I__

typedef struct
{
  float sth3xTempValue;
  float sth3xHumValue;
  bool DataVarFlg;
}tstempAndHum_typedef;

#endif