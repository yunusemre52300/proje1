#include <stdio.h>
#include "boards.h"
#include "app_util_platform.h"
#include "app_error.h"
#include "nrf_drv_twi.h"
#include "nrf_delay.h"


#include "nrf_log.h"
#include "nrf_log_ctrl.h"
#include "nrf_log_default_backends.h"
#include "i2c_h.h"
/* TWI instance ID. */
#define TWI_INSTANCE_ID     0

#define I2C_SCL_PIN             24    // SCL signal pin
#define I2C_SDA_PIN             22    // SDA signal pin

/* Indicates if operation on TWI has ended. */
static volatile bool m_xfer_done = false;
static volatile bool m_xfer_rx_done = false;
/* TWI instance. */
static const nrf_drv_twi_t m_twi = NRF_DRV_TWI_INSTANCE(TWI_INSTANCE_ID);

const uint32_t TWI_TIMEOUT = 100000;

/**
 * @brief TWI events handler.
 */
void twi_handler(nrf_drv_twi_evt_t const * p_event, void * p_context)
{
    
    switch (p_event->type)
    {
        case NRF_DRV_TWI_EVT_DONE: 
            if (p_event->xfer_desc.type == NRF_DRV_TWI_XFER_RX){}

            m_xfer_done = true;
            m_xfer_rx_done = true;
            break;
        default:
            break;
    }
}

/**
  * @brief  i2c �zerinden veri gondermeye yarayan fnc
  * @param  [in] address: sens�r adresi 
  * @param  [in] p_data: g�nderilecek data
  * @param  [in] length: p_data boyutu
  * @retval islem basarili bir sekilde olursa Result_OK d�n�l�r.
  */
int twiWriteData(uint8_t address, uint8_t * p_data, uint8_t length)
{
    ret_code_t err_code;
    uint32_t timeout = TWI_TIMEOUT;
    m_xfer_done = false;

    err_code = nrf_drv_twi_tx(&m_twi, address, p_data, length, false);
    if(err_code != NRF_SUCCESS) return -1; 

    while((!m_xfer_done) && --timeout);
    if(!timeout) return -1;

    return 1;
}

/**
  * @brief  i2c �zerinden veri okumayi saglayan fnc
  * @param  [in] address: sensor adresi 
  * @param  [out] p_data: okuma komutu
  * @param  [in] length: p_data uzunlu�u
  * @retval islem basarili bir sekilde olursa Result_OK d�n�l�r.
  */
int twiReadData(uint8_t address, uint8_t * p_data, uint8_t length)
{
    ret_code_t err_code;
    uint32_t timeout = TWI_TIMEOUT;
    m_xfer_rx_done = false;

    err_code = nrf_drv_twi_rx(&m_twi, address, p_data, length);
    if(err_code != NRF_SUCCESS) return -1; 

    // Wait until twi_rx done flag change or timeout
    timeout = TWI_TIMEOUT;
    while((!m_xfer_rx_done) && --timeout);
    if(!timeout) return -1;

    return 1;
}

/**
  * @brief  i2c hattini aktif eden fnc
  * @param  -
  * @retval -
  */
void twi_enable_fnc(void)
{
  nrf_drv_twi_enable(&m_twi);
}

/**
  * @brief  i2c hattini pasif eden fnc
  * @param  -
  * @retval -
  */
void twi_disable_fnc(void)
{
  nrf_drv_twi_disable(&m_twi);
}

void twi_deinit (void)
{
  nrfx_twi_uninit(&m_twi.u.twi);
}

void twi_init (void)
{
    ret_code_t err_code;

    const nrf_drv_twi_config_t twi_config = {
       .scl                = I2C_SCL_PIN,
       .sda                = I2C_SDA_PIN,
       .frequency          = NRF_DRV_TWI_FREQ_100K,
       .interrupt_priority = APP_IRQ_PRIORITY_HIGH,
       .clear_bus_init     = false
    };

    err_code = nrf_drv_twi_init(&m_twi, &twi_config, twi_handler, NULL);
    APP_ERROR_CHECK(err_code);
}
