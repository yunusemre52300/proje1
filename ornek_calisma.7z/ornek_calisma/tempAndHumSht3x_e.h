
#ifndef  __TEMP_AND_HUM_STH3X_E__
#define __TEMP_AND_HUM_STH3X_E__


extern void loopback_tempAndHum_Process(void);

#endif