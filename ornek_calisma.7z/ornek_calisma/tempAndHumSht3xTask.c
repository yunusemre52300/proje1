
#include <stdio.h>
#include "boards.h"
#include "app_util_platform.h"
#include "app_error.h"
#include "nrf_drv_twi.h"
#include "nrf_delay.h"


#include "nrf_log.h"
#include "nrf_log_ctrl.h"
#include "nrf_log_default_backends.h"
#include "i2c_h.h"

#include "tempAndHumSht3x_e.h"
#include "tempAndHumSht3x_i.h"

#define SHT3x          (0x44)

static uint8_t STH3TempatureAndHumidityBfr[6];

typedef unsigned char crc;

#define WIDTH  (8 * sizeof(crc))
#define TOPBIT (1 << (WIDTH - 1))
#define POLYNOMIAL 0x31

static crc crc8(unsigned char const message[], int nBytes)
{
    crc  remainder = 0xFF;	

    for (int byte = 0; byte < nBytes; ++byte)
    {
        remainder ^= (message[byte] << (WIDTH - 8));

        for (unsigned char bit = 8; bit > 0; --bit)
        {
            if (remainder & TOPBIT)
            {
                remainder = (remainder << 1) ^ POLYNOMIAL;
            }
            else
            {
                remainder = (remainder << 1);
            }
        }
    }

    return (remainder);
}

/**
  * @brief nem ve sicaklik Raw datasi pars edilir.
  * @param  -
  * @retval -
  */
static int STH3X_raw_data_pars_fnc(const uint8_t *temp, tstempAndHum_typedef *tempAndHum)
{
   uint8_t CopyBfr[2];
   tempAndHum->DataVarFlg = false;
   if(crc8(&temp[0],2) == temp[2])
     tempAndHum->sth3xTempValue = ((float)(175*(256*temp[0] + temp[1])))/65535.0 - 45;
   else
     return -1;

   if(crc8(&temp[3],2) == temp[5])
    tempAndHum->sth3xHumValue  = ((float)(100*(256*temp[3] + temp[4])))/65535.0;
   else
     return -1;

   tempAndHum->DataVarFlg = true;
   return 1;
}

/**
  * @brief  nem ve sicaklik verilerini okuma islemi
  * @param  -
  * @retval -
  */
static bool STH3X_read_temperature_and_humidity_sensor_fnc(tstempAndHum_typedef *tempAndHum)
{
    ret_code_t err_code;

    uint8_t reg[2] = {0x2c,0x06};

    if(1 != twiWriteData(SHT3x,reg,sizeof(reg)))
      return false;

    nrf_delay_ms(13);//d�n�s�m i�in gerekli zaman verilmistir.
    if(1 != twiReadData(SHT3x,STH3TempatureAndHumidityBfr, sizeof(STH3TempatureAndHumidityBfr)))
      return false;
    else
    {
      STH3X_raw_data_pars_fnc(STH3TempatureAndHumidityBfr,tempAndHum);
      return true;
    }
}

/**
  * @brief nem ve sicaklik islemlerinin periyodik olarak okunup islendigi fonksiyon
  * @param  -
  * @retval -
  */
void loopback_tempAndHum_Process(void)
{
    ret_code_t err_code;
    bool return_value;
    tstempAndHum_typedef tempAndHum_typedef;
    char CopyBfr[200];

    twi_enable_fnc();
    nrf_delay_ms(2);
    return_value = STH3X_read_temperature_and_humidity_sensor_fnc(&tempAndHum_typedef);
    twi_disable_fnc();

    memset(CopyBfr,0x00,sizeof(CopyBfr));
    if(return_value == 1 && tempAndHum_typedef.DataVarFlg == true && tempAndHum_typedef.sth3xTempValue > -70 && tempAndHum_typedef.sth3xTempValue < 127) // ge�erli bir data elde edilmistir.
    {
      snprintf(CopyBfr,sizeof(CopyBfr) - 1,"Okunan: Sicaklik Degeri:%f, Nem Degeri: %f \r\n", tempAndHum_typedef.sth3xTempValue,tempAndHum_typedef.sth3xHumValue);
    }
    else
    {
      strcat(CopyBfr, "Sensor Ile Haberlesme Basarili degildir.\r\n");
    }

    //sendDebugData(CopyBfr); burada herhangi bir kanaldan data basma ayarlanabilir.
}
